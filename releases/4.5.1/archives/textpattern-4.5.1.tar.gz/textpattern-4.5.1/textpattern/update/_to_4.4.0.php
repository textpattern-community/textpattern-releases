<?php

/*
$HeadURL: https://textpattern.googlecode.com/svn/releases/4.5.1/source/textpattern/update/_to_4.4.0.php $
$LastChangedRevision: 4011 $
*/

	if (!defined('TXP_UPDATE'))
	{
		exit("Nothing here. You can't access this file directly.");
	}

//	This page intentionally left blank.

?>
