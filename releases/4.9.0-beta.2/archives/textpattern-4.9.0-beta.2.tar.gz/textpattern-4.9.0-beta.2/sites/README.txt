The `/sites/` directory is part of Textpattern's multi-site functionality.

If you wish to use Textpattern in single-site mode only, you may remove this
directory with no ill effects.

Please see https://textpattern.com/textpattern-multi-site-installation for
further information and setup instructions.