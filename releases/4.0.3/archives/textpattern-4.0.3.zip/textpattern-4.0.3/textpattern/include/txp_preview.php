<?php
/*
$HeadURL$
$LastChangedRevision$
*/

include 'publish.php';

textpattern();

?>
