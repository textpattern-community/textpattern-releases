<?php
/*
$HeadURL: http://svn.textpattern.com/development/4.0/textpattern/include/txp_preview.php $
$LastChangedRevision: 628 $
*/

include 'publish.php';

textpattern();

?>
