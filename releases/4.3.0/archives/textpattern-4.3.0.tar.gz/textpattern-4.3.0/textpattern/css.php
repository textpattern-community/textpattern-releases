<?php
/*
@deprecated
@see ../css.php

$HeadURL: https://textpattern.googlecode.com/svn/releases/4.3.0/source/textpattern/css.php $
$LastChangedRevision: 3189 $
*/

if (!defined("txpath"))
{
	define("txpath", dirname(__FILE__));
}

require_once txpath.'/../css.php';
?>
