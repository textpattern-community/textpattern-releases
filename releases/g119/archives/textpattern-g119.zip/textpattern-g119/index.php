<?php

	include 'textpattern/config.php';
    include $txpcfg['txpath'].'/publish.php';
	textpattern();
?>
