This directory (sites) is optional. If you do not wish to host multiple
Textpattern sites from a single Textpattern installation, you may remove this
directory with no ill effects.

This directory may be used to create multiple Textpattern-based sites from a
single installation of Textpattern. With a multi-site setup, you may host
multiple sites while having only a single copy of the Textpattern core code to
maintain and update.

Please see https://docs.textpattern.com/installation/multi-site-textpattern for
full instructions.
