<?php
/*
$HeadURL: https://textpattern.googlecode.com/svn/development/4.0/textpattern/include/txp_preview.php $
$LastChangedRevision: 1238 $
*/
if (!defined('txpinterface')) die('txpinterface is undefined.');

include 'publish.php';

textpattern();

?>
