This directory (/sites) is intended for use with Textpattern's multi-site
functionality to create multiple Textpattern-managed sites using a single
instance of Textpattern. If you wish to use Textpattern in single-site mode
only, you may remove this directory with no ill effects.

Please see https://textpattern.com/textpattern-multi-site-installation for
further information and setup instructions.
