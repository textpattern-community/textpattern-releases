<?php
/*
$HeadURL: https://textpattern.googlecode.com/svn/development/4.x/sites/site1/public/css.php $
$LastChangedRevision: 3238 $
*/

include '../private/config.php';
include txpath.'/../css.php';
?>
