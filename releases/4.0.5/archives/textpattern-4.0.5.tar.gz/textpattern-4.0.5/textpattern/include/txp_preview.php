<?php
/*
$HeadURL: http://svn.textpattern.com/releases/4.0.5/source/textpattern/include/txp_preview.php $
$LastChangedRevision: 1238 $
*/
if (!defined('txpinterface')) die('txpinterface is undefined.');

include 'publish.php';

textpattern();

?>
