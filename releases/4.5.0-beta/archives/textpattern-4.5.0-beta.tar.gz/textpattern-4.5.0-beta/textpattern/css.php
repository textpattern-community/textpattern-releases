<?php
/*
@deprecated
@see ../css.php

$HeadURL: http://textpattern.googlecode.com/svn/development/4.x/textpattern/css.php $
$LastChangedRevision: 3189 $
*/

if (!defined("txpath"))
{
	define("txpath", dirname(__FILE__));
}

require_once txpath.'/../css.php';
?>
