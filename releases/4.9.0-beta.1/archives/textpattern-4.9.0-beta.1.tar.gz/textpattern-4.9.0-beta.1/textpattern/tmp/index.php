<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
  <!-- empty index.php to deter access or directory listings -->
  </body>
</html>
