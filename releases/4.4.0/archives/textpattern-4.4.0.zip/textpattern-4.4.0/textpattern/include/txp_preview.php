<?php
/*
$HeadURL: https://textpattern.googlecode.com/svn/releases/4.4.0/source/textpattern/include/txp_preview.php $
$LastChangedRevision: 1238 $
*/
if (!defined('txpinterface')) die('txpinterface is undefined.');

include 'publish.php';

textpattern();

?>
