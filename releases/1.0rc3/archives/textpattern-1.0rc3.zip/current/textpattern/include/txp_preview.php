<?php
/*
$HeadURL: http://svn.textpattern.com/current/textpattern/include/txp_preview.php $
$LastChangedRevision: 628 $
*/

include 'publish.php';

textpattern();

?>
